package com.example.fathima.notiification;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.FragmentManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button b1,b2,b3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(Button)findViewById(R.id.button);
        b2=(Button)findViewById(R.id.button2);
        b3=(Button)findViewById(R.id.button3);
        //toast notification
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Toast notification",Toast.LENGTH_SHORT).show();
            }
        });
        //status notification
        final Intent notificationIntent;
        notificationIntent = new Intent(this,MainActivity.class);
        final Context context=getApplicationContext();
        b2.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                Notification.Builder builder = new Notification.Builder(MainActivity.this);
                PendingIntent pendingIntent = PendingIntent.getActivity(context, 0,notificationIntent, 0);
                builder.setSmallIcon(R.drawable. not_icon)
                        .setContentTitle("Sample Status notification")
                        .setContentIntent(pendingIntent);
                NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                Notification notification = builder.getNotification();
                notificationManager.notify(R.drawable.not_icon, notification);
            }
        });
        //dialog notification
        b3.setOnClickListener(new View.OnClickListener() {
            SampleDialogFragment newRespond=new SampleDialogFragment();
            FragmentManager fm = getFragmentManager();

            @Override
            public void onClick(View v) {
                Bundle args = new Bundle();
                args.putString("response", "decline");
                newRespond.setArguments(args);
                newRespond.show(fm, "ok");
            }
        });
    }
}

@SuppressLint("ValidFragment")
class SampleDialogFragment extends DialogFragment {
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage(R.string.dialog_title)
                .setPositiveButton(R.string.dialog_yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User selected
                    }
                })
                .setNegativeButton(R.string.dialog_no, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User cancelled the dialog
                    }
                });
        // Create the AlertDialog object and return it
        return builder.create();
    }
}
