package com.example.surabhi.a3_buttons;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
Button b1,b2,b3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(Button) findViewById(R.id.b1);
        b2=(Button)findViewById(R.id.b2);
        b3=(Button)findViewById(R.id.b3);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getBaseContext(),"This is a toast message",Toast.LENGTH_SHORT).show();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.google.com"));
                PendingIntent pendingIntent=PendingIntent.getActivity(MainActivity.this,0,i,0);
                Notification notify=new Notification.Builder(MainActivity.this)
                        .setTicker("Important message")
                        .setContentTitle("New message")
                        .setContentText("Hello! You have a new message")
                        .setSmallIcon(R.drawable.img)


                        .setContentIntent(pendingIntent).getNotification();
                notify.flags=Notification.FLAG_AUTO_CANCEL;
                NotificationManager nm=(NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                nm.notify(0,notify);

            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog dialog=new AlertDialog.Builder(MainActivity.this).create();
                dialog.setTitle("Dialog message");
                dialog.setMessage("This is a dialog message");
                dialog.show();
            }
        });





    }

}
