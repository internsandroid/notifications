package com.example.surabhi.a3_buttons;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class notifications extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications2);
    }
}
